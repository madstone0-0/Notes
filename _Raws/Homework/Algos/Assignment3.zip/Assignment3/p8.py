"""
Strassen's Algorithm for matrix multiplication

Strassen's algorithm is an approach to matrix multiplication that reduces the number of basic operations needed to
multiply two nxn matrices from O(n^3) to O(n^2.81), where n is a power of 2. The strategy is as follows:
Given two nxn matrices A and B, where n is a power of 2 the product of these two matrices C can be derived by
reducing A, B and C into four quadrants, i.e.  n/2 x n/2 submatrices:

    C00 | C01     A00 | A01       B00 | B01
    ----|---- =   ----|----   *   ----|----
    C10 | C11     A10 | A11       B10 | B11

    Where:
    C00 =  M1 + M4 - M5 + M7
    C01 =  M3 + M5
    C10 =  M2 + M4
    C11 =  M1 - M2 + M3 + M6

    Using Strassen's formulae:
    M1 = (A00 + A11) * (B00 + B11)
    M2 = (A10 + A11) * B00
    M3 = A00 * (B01 - B11)
    M4 = A11 * (B10 - B00)
    M5 = (A00 + A01) * B11
    M6 = (A10 - A00) * (B00 + B01)
    M7 = (A01 - A11) * (B10 + B11)
"""

from typing import List, Tuple


type Matrix = List[List]


def m1(A: Matrix, B: Matrix):
    return (A[0][0] + A[1][1]) * (B[0][0] + B[1][1])


def m2(A: Matrix, B: Matrix):
    return (A[1][0] + A[1][1]) * B[0][0]


def m3(A: Matrix, B: Matrix):
    return A[0][0] * (B[0][1] - B[1][1])


def m4(A: Matrix, B: Matrix):
    return A[1][1] * (B[1][0] - B[0][0])


def m5(A: Matrix, B: Matrix):
    return (A[0][0] + A[0][1]) * B[1][1]


def m6(A: Matrix, B: Matrix):
    return (A[1][0] - A[0][0]) * (B[0][0] + B[0][1])


def m7(A: Matrix, B: Matrix):
    return (A[0][1] - A[1][1]) * (B[1][0] + B[1][1])


def subset(A: Matrix) -> Tuple[Matrix, Matrix, Matrix, Matrix]:
    n = len(A)

    A00 = []
    _0n2 = range(0, n // 2)
    _n2n = range(n // 2, n)
    for i in _0n2:
        temp = []
        for j in _0n2:
            temp += [A[i][j]]
        A00.append(temp)

    A01 = []
    for i in _0n2:
        temp = []
        for j in _n2n:
            temp += [A[i][j]]
        A01.append(temp)

    A10 = []
    for i in _n2n:
        temp = []
        for j in _0n2:
            temp += [A[i][j]]
        A10.append(temp)

    A11 = []
    for i in _n2n:
        temp = []
        for j in _n2n:
            temp += [A[i][j]]
        A11.append(temp)

    return A00, A01, A10, A11


def merge(A00: Matrix, A01: Matrix, A10: Matrix, A11: Matrix) -> Matrix:
    n = len(A00) * len(A00)
    C = []
    for i in range(n):
        temp = []
        for j in range(n):
            if i < n // 2:
                if j < n // 2:
                    temp += [A00[i][j]]
                else:
                    temp += [A01[i][j - n // 2]]
            else:
                if j < n // 2:
                    temp += [A10[i - n // 2][j]]
                else:
                    temp += [A11[i - n // 2][j - n // 2]]
        C.append(temp)
    return C


def printMat(A: Matrix):
    for row in A:
        print(row)


def matadd(A: Matrix, B: Matrix) -> Matrix:
    n = len(A)
    C = []
    for i in range(n):
        temp = []
        for j in range(n):
            temp += [A[i][j] + B[i][j]]
        C.append(temp)
    return C


def matsub(A: Matrix, B: Matrix) -> Matrix:
    n = len(A)
    C = []
    for i in range(n):
        temp = []
        for j in range(n):
            temp += [A[i][j] - B[i][j]]
        C.append(temp)
    return C


def matmul(A: Matrix, B: Matrix) -> Matrix:
    n = len(A)
    if n == 2:
        M1 = m1(A, B)
        M2 = m2(A, B)
        M3 = m3(A, B)
        M4 = m4(A, B)
        M5 = m5(A, B)
        M6 = m6(A, B)
        M7 = m7(A, B)
        return [
            [M1 + M4 - M5 + M7, M3 + M5],  #
            [M2 + M4, M1 + M3 - M2 + M6],  #
        ]
    A00, A01, A10, A11 = subset(A)
    B00, B01, B10, B11 = subset(B)
    AB00 = matmul(A00, B00)
    AB11 = matmul(A11, B11)
    C00 = matadd(AB00, matmul(A01, B10))
    C01 = matadd(matmul(A00, B01), matmul(A01, B11))
    C10 = matadd(matmul(A10, B00), matmul(A11, B10))
    C11 = matadd(matmul(A10, B01), AB11)
    return merge(C00, C01, C10, C11)


if __name__ == "__main__":
    A = [
        [0, 12, 2, 4],
        [8, 0, 10, 6],
        [3, 11, 0, 1],
        [5, 9, 7, 0],
    ]
    B = [
        [0, 45, 4, 12],
        [18, 0, 21, 14],
        [5, 32, 0, 2],
        [13, 20, 16, 0],
    ]
    printMat(matmul(A, B))
