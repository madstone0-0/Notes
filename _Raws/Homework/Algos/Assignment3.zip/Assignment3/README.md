## Requirements
Python 3.12+

## P7 - Question 7

Determines the closest pair of points in a list of x and corresponding y coords

### Usage
```python
python p7.py

```

## P8 - Question 8

Calculates $A * B = C$ using Strassen's matrix multiplication

### Usage

```python
python p8.py
```
